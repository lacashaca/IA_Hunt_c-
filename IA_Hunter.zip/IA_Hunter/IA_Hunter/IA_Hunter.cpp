#include <iostream>
#include <vector>
#include <ctime>

using namespace std;

struct caca
{
    int posicaoCacaY;
    int posicaoCacaX;
    bool encontrada;

};

struct s_cacador
{
    int posicaoCacadorY;
    int posicaoCacadorX;
    bool cacando;

};

int const linhas = 30;
int const colunas = 30;

int matriz[linhas][colunas];

vector <caca> cacas;
s_cacador cacador;



void CriaMatriz()
{
    for (int i = 0; i < linhas ; i++)
    {
        for (int j = 0; j < colunas; j++)
        {        

            matriz[i][j] = 0;

            //cout << matriz[i][j] << " "; 
        }
        //cout << endl;
    }
}

void ImprimeMatriz()
{
    for (int i = 0; i < linhas; i++)
    {
        for (int j = 0; j < colunas; j++)
        {
            cout << matriz[i][j] << " ";
        }
        cout << endl;
    }
}

void CriaPosicoes()
{
    srand(time(NULL));
    cacador.posicaoCacadorX = rand() % 30;
    cacador.posicaoCacadorX = rand() % 30;
    matriz[cacador.posicaoCacadorX][cacador.posicaoCacadorY] = 8;

    for (int i = 0; i < 5; i++)
    {
        caca temp;
        temp.posicaoCacaX = rand() % 30;
        temp.posicaoCacaY = rand() % 30;       

        while(cacador.posicaoCacadorX == temp.posicaoCacaX & cacador.posicaoCacadorY == temp.posicaoCacaY)
        {
            temp.posicaoCacaX = rand() % 30;
            temp.posicaoCacaY = rand() % 30;  
        }

        cacas.push_back(temp);       
        
        matriz[cacas[i].posicaoCacaX][cacas[i].posicaoCacaY] = i + 1;

        cout << cacas[i].posicaoCacaY << " ";
        cout << cacas[i].posicaoCacaX << " " << endl ;


    }
    
    
}

void MovimentaCacador()
{
    while (!cacador.cacando)
    {

    }
}

int main()
{
    CriaMatriz();
    CriaPosicoes();
    ImprimeMatriz();
}
